const API_URL = "https://jsonplaceholder.typicode.com/users";

const elements = {
  loading: document.querySelector("#loadingState"),
  error: document.querySelector("#errorState"),
  empty: document.querySelector("#emptyState"),
  data: document.querySelector("#dataState"),
  userList: document.querySelector("#userList"),
  errorMessage: document.querySelector("#errorMessage"),
  retryButton: document.querySelector("#retryButton"),
  reloadButton: document.querySelector("#reloadButton"),
  searchInput: document.querySelector("#searchInput"),
  resultCount: document.querySelector("#resultCount"),
  stateRegion: document.querySelector("#stateRegion")
};

let users = [];

function setState(state) {
  const states = ["loading", "error", "empty", "data"];
  states.forEach((name) => elements[name].classList.add("hidden"));
  elements[state].classList.remove("hidden");
  elements.stateRegion.setAttribute("aria-busy", state === "loading" ? "true" : "false");
}

function getInitials(name) {
  return name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

function userCardTemplate(user) {
  return `
    <article class="user-card">
      <div class="user-card__header">
        <div class="avatar" aria-hidden="true">${getInitials(user.name)}</div>
        <div>
          <h3>${user.name}</h3>
          <p class="user-card__username">@${user.username}</p>
        </div>
      </div>
      <ul class="detail-list">
        <li><span class="detail-label">Correo</span><span class="detail-value">${user.email.toLowerCase()}</span></li>
        <li><span class="detail-label">Ciudad</span><span class="detail-value">${user.address.city}</span></li>
        <li><span class="detail-label">Empresa</span><span class="detail-value">${user.company.name}</span></li>
        <li><span class="detail-label">Sitio</span><span class="detail-value">${user.website}</span></li>
      </ul>
    </article>
  `;
}

function renderUsers(list) {
  elements.resultCount.textContent = `${list.length} ${list.length === 1 ? "usuario" : "usuarios"}`;

  if (list.length === 0) {
    elements.userList.innerHTML = "";
    setState("empty");
    return;
  }

  elements.userList.innerHTML = list.map(userCardTemplate).join("");
  setState("data");
}

async function loadUsers() {
  setState("loading");
  elements.searchInput.disabled = true;
  elements.searchInput.value = "";
  elements.resultCount.textContent = "0 usuarios";

  try {
    const response = await fetch(API_URL);

    if (!response.ok) {
      throw new Error(`La API respondió con el estado ${response.status}.`);
    }

    const data = await response.json();

    if (!Array.isArray(data)) {
      throw new Error("La respuesta recibida no tiene el formato esperado.");
    }

    users = data;
    elements.searchInput.disabled = false;
    renderUsers(users);
  } catch (error) {
    console.error(error);
    elements.errorMessage.textContent = error.message || "No fue posible conectarse con la API.";
    setState("error");
  }
}

function filterUsers(query) {
  const normalized = query.trim().toLowerCase();

  if (!normalized) {
    renderUsers(users);
    return;
  }

  const filtered = users.filter((user) => {
    const searchableText = [
      user.name,
      user.username,
      user.email,
      user.address.city,
      user.company.name
    ].join(" ").toLowerCase();

    return searchableText.includes(normalized);
  });

  renderUsers(filtered);
}

elements.retryButton.addEventListener("click", loadUsers);
elements.reloadButton.addEventListener("click", loadUsers);
elements.searchInput.addEventListener("input", (event) => filterUsers(event.target.value));

document.addEventListener("DOMContentLoaded", loadUsers);
