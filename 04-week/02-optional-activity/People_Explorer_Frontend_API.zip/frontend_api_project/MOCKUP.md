# Mockup de la vista principal

El mockup plantea una vista de tipo **lista de elementos** representada mediante tarjetas de usuarios.
La distribución propuesta prioriza jerarquía visual, lectura rápida y adaptación a dispositivos móviles.

```text
┌───────────────────────────────────────────────────────────────┐
│ PE  People Explorer                              [Recargar]  │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  FRONTEND + API                                               │
│  Explora perfiles de forma rápida y clara       [10 usuarios] │
│  Información obtenida desde JSONPlaceholder                   │
│                                                               │
├───────────────────────────────────────────────────────────────┤
│ Buscar                                                        │
│ [ Nombre, usuario, correo o ciudad...                      ]   │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│ ┌────────────────┐ ┌────────────────┐ ┌────────────────┐     │
│ │ AB  Leanne     │ │ ER  Ervin      │ │ CP  Clementine │     │
│ │ @Bret          │ │ @Antonette     │ │ @Samantha      │     │
│ │ Correo         │ │ Correo         │ │ Correo         │     │
│ │ Ciudad         │ │ Ciudad         │ │ Ciudad         │     │
│ │ Empresa        │ │ Empresa        │ │ Empresa        │     │
│ └────────────────┘ └────────────────┘ └────────────────┘     │
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

## Estados contemplados

- **Carga:** spinner y mensaje mientras se ejecuta `fetch`.
- **Datos:** tarjetas de usuarios cuando la respuesta es correcta.
- **Error:** mensaje explicativo y botón para volver a intentar.
- **Sin resultados:** mensaje cuando el filtro no encuentra coincidencias.

## Responsive

- Escritorio: 3 columnas.
- Tablet: 2 columnas.
- Móvil: 1 columna.
