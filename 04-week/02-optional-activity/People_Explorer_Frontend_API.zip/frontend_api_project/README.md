# People Explorer

Proyecto frontend desarrollado con **HTML, CSS y JavaScript puro**. La aplicación consume una API pública con `fetch`, muestra una lista de usuarios y administra los estados de carga, datos y error.

## Overview

People Explorer is a small frontend application designed to display a clean and responsive list of users. It consumes the public JSONPlaceholder API through the browser Fetch API. While the request is in progress, the interface shows a dedicated loading state with a visual spinner. When the API responds successfully, the application renders the received users as reusable cards and enables a client-side search filter. If the network request fails or the API returns an invalid response, an error state is displayed with a retry action. The interface also includes an empty state when the search does not match any user. The project is organized using separate HTML, CSS, and JavaScript files to keep the structure easy to understand and maintain.

## API utilizada

Endpoint:

```text
https://jsonplaceholder.typicode.com/users
```

La API devuelve usuarios de ejemplo con datos como nombre, correo, ciudad, empresa y sitio web.

## Funcionalidades

- Consumo de API con `fetch` y `async/await`.
- Estado de carga mientras se consulta la API.
- Estado de datos con tarjetas de usuarios.
- Estado de error con mensaje y botón de reintento.
- Estado vacío para búsquedas sin coincidencias.
- Buscador por nombre, usuario, correo, ciudad o empresa.
- Diseño responsive para escritorio, tablet y móvil.
- Estructura separada en HTML, CSS y JavaScript.

## Mockup

El diseño previo y la distribución de la vista se encuentran en el archivo `MOCKUP.md`.

## Estructura del proyecto

```text
frontend_api_project/
├── index.html
├── styles.css
├── app.js
├── MOCKUP.md
├── README.md
└── .gitignore
```

## Cómo ejecutar el proyecto

### Opción 1: abrir directamente

1. Descomprime el archivo ZIP.
2. Abre la carpeta del proyecto.
3. Haz doble clic en `index.html`.
4. Se abrirá en el navegador y cargará los datos desde la API.

### Opción 2: usar un servidor local

Si tienes Python instalado, abre una terminal dentro de la carpeta del proyecto y ejecuta:

```bash
python -m http.server 5500
```

Después abre en el navegador:

```text
http://localhost:5500
```

También puedes utilizar la extensión **Live Server** de Visual Studio Code.

## Versionamiento con Git

El proyecto fue inicializado como repositorio Git y contiene un commit inicial. Para revisar el historial puedes ejecutar:

```bash
git log --oneline
```

Si deseas continuar trabajando en el proyecto:

```bash
git add .
git commit -m "Describe your changes"
```

## Tecnologías

- HTML5
- CSS3
- JavaScript ES6+
- Fetch API
- JSONPlaceholder
- Git
